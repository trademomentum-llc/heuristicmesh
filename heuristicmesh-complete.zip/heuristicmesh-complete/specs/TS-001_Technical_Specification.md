# HeuristicMesh Fall Detection System
## Technical Specification (TS-001)
**Version:** 1.0  
**Date:** 2026-08-17

---

## 1. Hardware Platform

### 1.1 Thermal Node
- MCU: ESP32-WROOM-32 (or ESP32 DevKitC with CP2102)
- Sensor: Panasonic AMG8833 (8×8 thermal array, I2C 0x69)
- I2C: GPIO21 (SDA), GPIO22 (SCL), 400 kHz, 4.7 kΩ pull-ups to 3.3 V
- Power: 5 V USB-C → 3.3 V LDO
- Output: USB serial @ 115200 baud (binary + text)

### 1.2 Edge Compute
- 1–2 × NVIDIA Jetson Orin Nano
- Receives serial stream from thermal node
- Runs Framework 2 spatial analysis

### 1.3 Ground Truth
- Body cameras (CQH Mini, Ksadbossbo or equivalent)
- Independent wall-clock logging

### 1.4 Archive / Orchestration
- ASUS NUC (stationary)
- Optional Zyxel networking (USG Flex 100H, GS1200, NWA50AX or equivalent)

## 2. Software Architecture

### 2.1 Framework Map
| Framework | Location | Responsibility |
|-----------|----------|----------------|
| FW1       | ESP32    | Thermal sampling, centroid, velocity, fall-candidate flag |
| FW2       | Jetson   | Spatial confirmation, ring buffer, event emission |
| FW3       | Jetson/NUC | Event classification (future) |
| FW4       | Hub/Cloud | Alerting & response (future) |

### 2.2 Binary Protocol (ESP32 → Jetson)
```
Offset  Size  Type     Description
0       1     uint8    Magic = 0xA5
1       4     uint32   Frame counter (LE)
5       1     uint8    Flags (bit0=fall candidate, bit1=centroid valid)
6       2     int16    Max temperature ×100 (°C)
8       2     int16    Avg temperature ×100 (°C)
10      1     uint8    Hot pixel count
11      2     int16    Centroid X ×100 (0–7 grid)
13      2     int16    Centroid Y ×100
15      2     int16    Velocity ×100 (grid cells/frame)
17      2     int16    Mass ×10
Total: 19 bytes
```

### 2.3 Configuration
All tunable thresholds live in:
- `esp32/include/config.h`
- `config/thresholds.yaml`

## 3. Performance Targets
- Thermal sample rate: 20 Hz (50 ms interval)
- End-to-end latency (sensor → Framework 2 event): < 300 ms typical
- Ring buffer depth: ≥ 15 s
- False-positive behavior: tunable via velocity and persistence thresholds

## 4. Data Persistence
- Jetson writes structured events to `thermal_events.jsonl`
- Body-cam sessions logged via CSV template
- No raw thermal video stored by default (privacy)

## 5. Interfaces
- Serial: USB CDC / UART 115200 8N1
- Future: MQTT topics defined in `config/mqtt_topics.md`
- Power: USB-C 5 V

## 6. Safety & Privacy
- Thermal only – no identifiable imagery
- No continuous cloud upload in baseline configuration
- Local processing preferred
