# HeuristicMesh Fall Detection System
## Design Specification (DS-001)
**Version:** 1.0  
**Date:** 2026-08-17

---

## 1. Design Goals
1. Privacy-first sensing (thermal only on primary path)
2. Explainable detection (HeuristicMesh layered heuristics)
3. Field-collectable ground truth via body cameras
4. Path to a manufacturable consumer node under $25 COGS
5. Operable with currently available hardware (AMG8833 only)

## 2. Logical Architecture

```
[AMG8833] --I2C--> [ESP32 FW1] --USB Serial--> [Jetson FW2] --JSONL/MQTT--> [NUC / Hub]
                                              ^
                                              |
                                      [Body Cameras] (ground truth, independent)
```

## 3. Thermal Node Design
- Single AMG8833 looking into the room or downward
- ESP32 performs all first-stage feature extraction
- Binary protocol minimizes wire traffic and parsing cost
- Human-readable status lines retained for debugging

## 4. Edge Design (Jetson)
- Stateless packet parser with magic-byte resynchronization
- Fixed-size ring buffer (time-bounded)
- Framework 2 evaluates short temporal windows for net downward motion + velocity
- Events are append-only JSONL for later review and training

## 5. Consumer Product Design (Target)
- Enclosure: ≤ 90 × 90 × 30 mm, wall or ceiling mount
- Power: USB-C 5 V
- Connectivity: ESP32 Wi-Fi
- Electronics: ESP32-WROOM-32 + AMG8833 + 3.3 V LDO + minimal passives
- Cost target: $17–23 COGS at 1k units
- Retail target: $79–99

## 6. Data Collection Design
- **Mode A (active):** Body-cam only, portable, maximizes actor diversity
- **Mode B (later):** Co-located thermal + body-cam for multi-modal ground truth
- Scenarios prioritized by clinical relevance and difficulty (S01–S03 common, S06/S10 elusive)

## 7. Key Design Decisions
| Decision | Rationale |
|----------|-----------|
| AMG8833 only | MLX90640 unavailable; 8×8 still sufficient for coarse fall dynamics |
| On-device centroid + velocity | Reduces Jetson load and serial bandwidth |
| Binary + text dual output | Machine efficiency + human debug |
| No camera on primary path | Privacy and cost |
| HeuristicMesh over pure NN | Explainability and lower data requirements for v1 |

## 8. Future Extensions (Non-blocking)
- MQTT transport for multi-node homes
- Framework 3 classification layer
- Optional NIR or secondary thermal for disambiguation
- Battery or PoE variants of the consumer node
