# HeuristicMesh Fall Detection System
## Requirements Document (REQ-001)
**Version:** 1.0  
**Date:** 2026-08-17  
**Status:** Baseline – AMG8833 Thermal Path

---

## 1. Purpose
Define the functional, performance, and operational requirements for a privacy-first, explainable fall-detection system suitable for residential deployment and subsequent manufacturing as a consumer product.

## 2. System Overview
The system detects potential falls using an 8×8 thermal array (AMG8833), performs edge spatial analysis on Jetson-class hardware, and supports body-camera ground-truth collection for algorithm validation and training.

## 3. Functional Requirements

### FR-1 Thermal Sensing
- The system shall sample an 8×8 thermal array at a minimum of 10 Hz (target 20 Hz).
- The system shall compute max temperature, average temperature, hot-pixel count, centroid location, and short-term centroid velocity on-device or on the first edge compute node.
- The system shall raise a fall-candidate flag when velocity and persistence thresholds are exceeded.

### FR-2 Edge Analysis
- A Jetson-class node shall receive the thermal telemetry stream.
- The node shall maintain a rolling buffer of at least 10 seconds of thermal frames.
- The node shall apply spatial heuristics (net downward motion + velocity) and emit structured events.

### FR-3 Ground Truth
- The system shall support synchronized body-camera recording for validation.
- Session logging shall capture actor identifier, scenario ID, wall-clock timestamps, and environmental notes.

### FR-4 Data Output
- Thermal nodes shall emit a compact binary protocol over serial (and optionally Wi-Fi/MQTT).
- Events shall be written to persistent JSONL logs with timestamps and confidence values.

### FR-5 Consumer Node (Future Product)
- A wall- or ceiling-mountable thermal node shall be defined that can be manufactured at consumer cost targets.
- The node shall operate from 5 V USB-C power and communicate over Wi-Fi.

## 4. Non-Functional Requirements

### NFR-1 Privacy
- No RGB or depth camera is required on the primary sensing path.
- Thermal resolution shall remain low (8×8) to prevent identifiable imagery.

### NFR-2 Explainability
- Primary detection path shall use inspectable heuristics (HeuristicMesh frameworks) rather than opaque end-to-end neural models.

### NFR-3 Reliability
- The thermal node shall recover from USB disconnects and continue operation after power cycles.
- Serial protocol shall include a magic byte and frame counter for resynchronization.

### NFR-4 Cost & Manufacturability
- Electronics + enclosure cost target for the consumer node: ≤ $25 at 1 000-unit quantity.
- Retail target: $79–$99.

## 5. Constraints
- MLX90640 high-resolution thermal sensor is unavailable; system is constrained to AMG8833.
- Multi-modal capture (thermal + body-cam) is limited to locations where the fixed hardware can be co-located.
- Zyxel network infrastructure is optional and not required for field data collection.

## 6. Out of Scope (Current Baseline)
- On-device neural network inference
- Battery-powered operation
- Real-time cloud alerting (deferred to later Framework 4)
- High-resolution thermal imaging

## 7. Acceptance Criteria
- ESP32 firmware produces continuous binary telemetry and human-readable status.
- Jetson daemon parses packets, maintains ring buffer, and logs Framework-2 events.
- Body-cam sessions can be logged with the provided template.
- Consumer product definition exists with schematic, mechanical, and BOM targets.
